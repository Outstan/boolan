package com.example.boolan.utils;

/**
 * 作者：pc on 2017/2/6 10:46
 * 功能：
 * 参数：
 */

public class ConstantUtil {
    public  static String SERVER_ADDRESS="http://103.40.24.41:8080";
    public  static String SERVER_ADDRES="103.40.24.41:8080";

//    public  static String SERVER_ADDRESS="http://192.168.31.118:8080";
//    public  static String SERVER_ADDRES="192.168.31.118:8080";

//    public  static String SERVER_ADDRESS="http://192.168.1.8:8080";
//    public  static String SERVER_ADDRES="192.168.1.8:8080";

//    public  static String SERVER_ADDRESS="http://120.27.218.220:8080";
//    public  static String SERVER_ADDRES="120.27.218.220:8080";
}
